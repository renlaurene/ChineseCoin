public class Hole {

	private double side;
	
	//Helping function
	private double square(double i){
		return i*i;
	}
	
	//Constructor 
	public Hole(double s){
		this.side = s;
	}
	
	//Access function
	public double getSide(){
		return this.side;
	}
	public void setSide(double s){
		this.side = s;
	}
	public boolean isLarge(){
		return this.side > 10;
	}
	
	//Implementor
	public double area(){
		return square(this.side);
	}
	public double circumference(){
		return 4*this.side;
	}	
}