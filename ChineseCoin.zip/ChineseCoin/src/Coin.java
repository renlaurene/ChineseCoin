public class Coin {
	
	private double radius;
	private Hole square = new Hole(0);
	
	//Helping function
	private double pi(){
		return 3.1416;
	}
	private double diagnal(){
		return 1.414;
	}
	//Manager function
	public Coin(double s, double r){
		square.setSide(s);
		this.radius = r;
	}

	//Access function
	public Hole getSquare(){
		return square;
	}
	public void setSquare(double s){
		square.setSide(s);
	}
	public double getRadius(){
		return this.radius;
	}
	public void setRadius(double r){
		this.radius = r;
	}
	public boolean isNormal(){
		return 2*this.radius > diagnal()*square.getSide();
	}
	
	//Implementor
	public double area(){
		return pi()*this.radius*this.radius - square.area();
	}
}

