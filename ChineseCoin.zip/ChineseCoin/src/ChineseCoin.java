public class ChineseCoin{

	public static void main(String[] args) {
		Coin coin = new Coin(2,2);
		if (coin.isNormal()){
			System.out.println("This is normal coin");
		}else{
			System.out.println("This is not a coin");
		}
        System.out.println(coin.area());
	}
}
